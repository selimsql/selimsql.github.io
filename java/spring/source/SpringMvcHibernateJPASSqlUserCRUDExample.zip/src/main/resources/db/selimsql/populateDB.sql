Insert into User(Id, Code, Name, Surname, Email, Password, Phone, Status)
Values(SequenceNextValue('SEQ_USERPK'), 'admin', 'Admin', 'Admin', 'admin@test.com', 'admin', null, 1);
