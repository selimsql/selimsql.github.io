Insert into User(Id, Code, Name, Surname, Email, Password, Phone, Status)
Values(1, 'admin', 'Admin', 'Admin', 'admin@test.com', 'admin', null, 1);

Insert into User(Id, Code, Name, Surname, Email, Password, Phone, Status)
Values(2, 'zguven', 'Zülkif', 'Güven', 'zguven@test.com', 'zguven', null, 1);

