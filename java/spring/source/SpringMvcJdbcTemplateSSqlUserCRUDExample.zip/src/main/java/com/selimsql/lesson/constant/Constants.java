package com.selimsql.lesson.constant;

public class Constants {
	public static final String AUTHORITYVALUE_Add     = "Add";
	public static final String AUTHORITYVALUE_Show    = "Show";
	public static final String AUTHORITYVALUE_Update  = "Update";
	public static final String AUTHORITYVALUE_Delete  = "Delete";
}
