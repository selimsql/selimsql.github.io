Insert into User(Id, Code, Name, Surname, Password, Phone, Status)
Values(SequenceNextValue('SEQ_USER_PK'), 'admin', 'Admin', 'Admin', '1111', null, 1);

#!TEMP?
Insert into User(Id, Code, Name, Surname, Password, Phone, Status)
Values(33, 'zguven', 'Zülkif', 'Güven', '1111', null, 1);
