package selimsqldb.example;

import java.sql.Connection;
import java.sql.SQLException;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class SSqlDbTestActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mainlayout);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.mainlayout, menu);
		return true;
	}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	int itemId = item.getItemId();
        if (itemId==R.id.menu_new_database) {
        	doNewDatabase();
        	return true;
        }
        else
        if (itemId==R.id.menu_connect_database) {
        	doConnectDatabase();
        	return true;
        }
        else
        if (itemId==R.id.menu_build_tables) {
        	doBuildTables();
        	return true;
        }
        else
        if (itemId==R.id.menu_insert_update_records) {
        	doInsertUpdateRecords();
        	return true;
        }
        else
        if (itemId==R.id.menu_insert_update_by_prepared) {
        	doInsertUpdateRecordsByPrepared();
        	return true;
        }
        else
        if (itemId==R.id.menu_select_records) {
        	doSelectRecords();
        	return true;
        }

        return super.onOptionsItemSelected(item);
    }

	private void showToast(String info) {
		Toast toast = Toast.makeText(this, info, Toast.LENGTH_LONG);
		toast.show();
	}

	private boolean doNewDatabase() {
		NewSSqlDb newSSqlDb = new NewSSqlDb();
		Connection connection = null;
		String error = null;
		try {
			connection = newSSqlDb.newDb(DbConstant.SELIMSQL_DB_TEST_NAME);
			//...
		}
		catch(Exception ex) {
			error = "Error:" + ex.getMessage();
			System.out.println(error);
		}
		finally {
			newSSqlDb.closeDb(connection);
		}

		String msg = (error==null ? "NewDbOkay" : error);
		showToast(msg);
		return (connection!=null);
    }


    private boolean doConnectDatabase() {
		ConnectSSqlDb connectSSqlDb = new ConnectSSqlDb();
		Connection connection = null;
		try {
			connection = connectSSqlDb.connectDb(DbConstant.SELIMSQL_DB_TEST_NAME);

			//...
		}
		finally {
			connectSSqlDb.closeDb(connection);
		}

		String msg = "ConnectDb:" + (connection==null ? "FAILED" : "SUCCESSFUL");
		showToast(msg);
		return (connection!=null);
    }

    private boolean doBuildTables() {
		ConnectSSqlDb connectSSqlDb = new ConnectSSqlDb();
		Connection connection = null;
		String error = null;
		try {
			connection = connectSSqlDb.connectDb(DbConstant.SELIMSQL_DB_TEST_NAME);
			if (connection==null)
				throw new SQLException("Connection Failed!");

			BuildTableSSqlDb buildTableSSqlDb = new BuildTableSSqlDb();
			buildTableSSqlDb.buildTablesAndIndexes(connection);
		}
		catch(Exception ex) {
			error = "Error:" + ex.getMessage();
			System.out.println(error);
		}
		finally {
			connectSSqlDb.closeDb(connection);
		}

		boolean successful = (error==null);
		String msg = "BuildTables:" + (successful ? "SUCCESSFUL" : error);
		showToast(msg);
		return successful;
    }

    private boolean doInsertUpdateRecords() {
		ConnectSSqlDb connectSSqlDb = new ConnectSSqlDb();
		Connection connection = null;
		String error = null;
		String msg = null;
		try {
			connection = connectSSqlDb.connectDb(DbConstant.SELIMSQL_DB_TEST_NAME);
			if (connection==null)
				throw new SQLException("Connection Failed!");

			DmlOpSSqlDb dmlOpSSqlDb = new DmlOpSSqlDb();
			msg = "InsertRecords:" + dmlOpSSqlDb.insertUpdateDeleteRecords(connection);
		}
		catch(Exception ex) {
			error = "Error:" + ex.getMessage();
			System.out.println(error);
		}
		finally {
			connectSSqlDb.closeDb(connection);
		}

		boolean successful = (error==null);
		msg = (successful ? "SUCCESSFUL(" + msg + ")" : error);
		showToast(msg);
		return successful;
    }

    private boolean doInsertUpdateRecordsByPrepared() {
		ConnectSSqlDb connectSSqlDb = new ConnectSSqlDb();
		Connection connection = null;
		String error = null;
		String msg = null;
		try {
			connection = connectSSqlDb.connectDb(DbConstant.SELIMSQL_DB_TEST_NAME);
			if (connection==null)
				throw new SQLException("Connection Failed!");

			DmlPreparedOpSSqlDb dmlPreparedOpSSqlDb = new DmlPreparedOpSSqlDb();
			msg = "InsertRecordsByPrepared:" + dmlPreparedOpSSqlDb.insertUpdateRecords(connection);
		}
		catch(Exception ex) {
			error = "Error:" + ex.getMessage();
			System.out.println(error);
		}
		finally {
			connectSSqlDb.closeDb(connection);
		}

		boolean successful = (error==null);
		msg = (successful ? "SUCCESSFUL(" + msg + ")" : error);
		showToast(msg);
		return successful;
    }

    private boolean doSelectRecords() {
		ConnectSSqlDb connectSSqlDb = new ConnectSSqlDb();
		Connection connection = null;
		String error = null;
		String msg = null;
		try {
			connection = connectSSqlDb.connectDb(DbConstant.SELIMSQL_DB_TEST_NAME);
			if (connection==null)
				throw new SQLException("Connection Failed!");

			SelectRecSSqlDb selectRecSSqlDb = new SelectRecSSqlDb();
			int row = selectRecSSqlDb.selectProductRecords(connection);
			msg = "SelectProductRecords:" + row;

			selectRecSSqlDb.selectOrderRecords(connection);
			row = selectRecSSqlDb.selectOrderRecords(connection);
			msg += ", SelectOrderRecords:" + row;
		}
		catch(Exception ex) {
			error = "Error:" + ex.getMessage();
			System.out.println(error);
		}
		finally {
			connectSSqlDb.closeDb(connection);
		}

		boolean successful = (error==null);
		msg = (successful ? "SUCCESSFUL(" + msg + ")" : error);
		showToast(msg);
		return successful;
    }
}
